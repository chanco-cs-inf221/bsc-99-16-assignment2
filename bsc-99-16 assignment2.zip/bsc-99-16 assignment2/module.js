
 function save(){
  var name = document.getElementsByName('projectName').value=name
	var Description = document.getElementsByName('projectDescription').value=Description
	var cDate = document.getElementsByName('completionDate').value=cDate


  localStorage.setItem('name',name);
	localStorage.setItem('projectDescription', Description);
	localStorage.setItem('completionDate',cDate);

  
var organizationName=document.getElementsByName('organization').value=organizationName
var endDate=document.getElementsByName('Edate').value=endDate

localStorage.setItem('organizationName',organizationName);
localStorage.setItem('endDate',endDate);

function work(){
  var storedValue = localStorage.getItem('organizationName');
  var storedValue = localStorage.getItem('endDate');
 
}

function cleared(){
  localStorage.removeItem('organizationName');
	localStorage.removeItem('endDate');
}
 }